# Color-Identification-using-Machine-Learning
This project uses Machine Learning to extract a set number of colors from an image.
